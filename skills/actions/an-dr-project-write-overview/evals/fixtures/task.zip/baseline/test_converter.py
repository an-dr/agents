from converter import parse

assert parse("a\n1") == [{"a": "1"}]
