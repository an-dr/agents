import csv
import json
import sys

def parse(text):
    return list(csv.DictReader(text.splitlines()))

def main():
    json.dump(parse(sys.stdin.read()), sys.stdout)

if __name__ == "__main__":
    main()
