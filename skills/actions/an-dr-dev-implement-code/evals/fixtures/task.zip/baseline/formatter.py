def format_name(name):
    return f"Name: {name}"
