from formatter import format_name

assert format_name("Ada") == "Name: Ada\n"
