import csv
import sys

def export(rows):
    csv.writer(sys.stdout).writerows(rows)
