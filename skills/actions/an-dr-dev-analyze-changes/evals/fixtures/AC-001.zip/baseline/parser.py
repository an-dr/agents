def parse_count(text):
    text = text.strip()
    if not text:
        raise ValueError('empty count')
    return int(text)
