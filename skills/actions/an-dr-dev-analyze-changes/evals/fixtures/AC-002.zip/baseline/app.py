from cache import Cache

def build_handler(loader):
    cache = Cache(loader)
    return lambda key: cache.get(key)
