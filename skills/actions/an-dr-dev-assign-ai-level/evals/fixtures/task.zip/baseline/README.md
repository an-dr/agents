# Ledger

[![Build](https://img.shields.io/badge/build-passing-brightgreen)](https://example.invalid/build)
[![License](https://img.shields.io/badge/license-MIT-blue)](LICENSE)

Ledger turns a CSV export into a per-account summary.

## Usage

Install with `pip install -e .`, then run `ledger` on a CSV file.

## Development

Run `pytest` for the tests.
