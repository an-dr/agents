import csv
from collections import defaultdict


def summarize(rows):
    totals = defaultdict(float)
    for row in rows:
        totals[row["account"]] += float(row["amount"])
    return dict(totals)


def main(path):
    with open(path, newline="", encoding="utf-8") as handle:
        return summarize(csv.DictReader(handle))
