from src.ledger import summarize


def test_sums_per_account():
    rows = [
        {"account": "a", "amount": "2"},
        {"account": "a", "amount": "3"},
    ]
    assert summarize(rows) == {"a": 5.0}
