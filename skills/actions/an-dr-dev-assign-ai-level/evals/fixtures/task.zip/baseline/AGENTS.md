# Agent instructions

Use the `ledger` CLI to turn a CSV export into a per-account summary.
Keep the module and its tests in sync; run `pytest` before reporting.
