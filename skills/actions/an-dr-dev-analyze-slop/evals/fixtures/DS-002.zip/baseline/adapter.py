class Adapter:
    def __init__(self, transform):
        self.transform = transform

    def invoke(self, value):
        return self.transform(value)
