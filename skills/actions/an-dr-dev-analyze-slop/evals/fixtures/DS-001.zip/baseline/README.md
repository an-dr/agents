# Counter

parse_count accepts only non-negative integers.
