def identity(value):
    copied = value
    return copied
