def parse_count(text):
    value = int(text)
    if value < 0:
        raise ValueError('negative count')
    return value
