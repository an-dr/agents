# Counter

parse_count accepts only non-negative integers. Input validation is now simpler.
