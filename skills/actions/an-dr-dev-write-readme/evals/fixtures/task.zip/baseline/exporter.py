import csv
import sys

def main():
    rows = list(csv.DictReader(sys.stdin))
    print(rows)

if __name__ == "__main__":
    main()
